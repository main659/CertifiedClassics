<template>
  <div>Voucher with id: {{ $route.params.id }}</div>
</template>

<script>
export default {
  name: "VoucherDetail"
};
</script>
