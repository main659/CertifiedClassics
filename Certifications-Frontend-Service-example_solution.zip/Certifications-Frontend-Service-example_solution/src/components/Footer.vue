<template>
  <v-footer dark> {{ new Date().getFullYear() }} Java Academy </v-footer>
</template>
